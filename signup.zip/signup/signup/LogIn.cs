﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace signup
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            Form1 signup = new Form1();
            signup.Show();
            Visible = false;
        }

        private void LogInButton_Click(object sender, EventArgs e)
        {
            string encappedpass = Aescryp.Encrypt(textBox2.Text);
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=usersdb;Integrated Security=True");
            SqlCommand cmd = new SqlCommand(@"select * from usertable where username = '" + textBox1.Text + "' and pass = '" + encappedpass + "'", con);
            
            SqlDataAdapter adpt = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            adpt.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                if (textBox1.Text == "admin")
                {
                    MessageBox.Show("SUCCESSFULLY LOG IN!");
                    Home home = new Home();
                    home.Show();
                    Visible = false;
                }
                else
                {
                    HomeUser home = new HomeUser();
                    home.Show();
                    Visible = false;
                }
            }

            else
            {
                MessageBox.Show("INVALID!");
            }

            textBox1.Text = "";
            textBox2.Text = "";

        }
    }
}
