﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Data.SqlClient;

namespace signup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SignUpButton_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=.;Initial Catalog=usersdb;Integrated Security=True");
            SqlCommand cmd1 = new SqlCommand(@"select * from usertable where username = '" + usernameTextbox.Text +  "'", con1);

            SqlDataAdapter adpt = new SqlDataAdapter(cmd1);

            DataTable dt = new DataTable();

            adpt.Fill(dt);

            


            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("INVALID INPUT ON EMAIL!");
            }

            else
            {
               

                if (passwordTextbox.Text == confirmTextbox.Text)
                {
                    if (passwordTextbox.Text.Length < 8)
                    {
                        MessageBox.Show("Invalid length!");
                    }
                    else
                    {
                        string encappedpass = Aescryp.Encrypt(passwordTextbox.Text);
                        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=usersdb;Integrated Security=True");
                        SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[usertable] ([username], [pass]) VALUES ('" + usernameTextbox.Text + "', '" + encappedpass + "')", con);



                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Account successfulyy added!!");
                        usernameTextbox.Text = "";
                        passwordTextbox.Text = "";
                        confirmTextbox.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Invalid!");
                }
            }


            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Registerbutton_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            login.Show();
            Visible = false;
        }
    }
}
